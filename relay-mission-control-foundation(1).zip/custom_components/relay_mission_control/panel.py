"""Panel registration."""
